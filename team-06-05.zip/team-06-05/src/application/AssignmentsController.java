package application;

import application.cell.DateEditingCell;
import application.cell.EditingCell;
import java.time.ZoneId;
import java.util.Date;
import java.util.Map;
import java.util.Optional;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.util.Callback;

public class AssignmentsController {

  private final TableView<ObservableAssignment> table = new TableView<>();
  private final ObservableList<ObservableAssignment> data;
  final HBox hb = new HBox();
  final Button save = new Button("Save");

  private final StudentReminder studentReminder;
  private final Map<String, ObservableAssignment> database;
  private final AssignmentDB assignmentDB;
  private ObservableAssignment selectedAssignment;

  public AssignmentsController(StudentReminder studentReminder, AssignmentDB assignmentDB) {
    this.studentReminder = studentReminder;
    this.database = assignmentDB.getDatabase();
    this.assignmentDB =assignmentDB;
    data = FXCollections.observableArrayList(database.values());
  }

  public Scene createScene() {
    //Label for Assignment
    Label label = new Label("Assignments for " + assignmentDB.getUsername());
    Font font = Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 12);
    label.setFont(font);

    //Creating columns that allows editing text and data
    Callback<TableColumn<ObservableAssignment, String>, TableCell<ObservableAssignment, String>> cellFactory
        = (TableColumn<ObservableAssignment, String> param) -> new EditingCell();
    Callback<TableColumn<ObservableAssignment, Date>, TableCell<ObservableAssignment, Date>> dateCellFactory
        = (TableColumn<ObservableAssignment, Date> param) -> new DateEditingCell();

    TableColumn<ObservableAssignment, String> nameCol = new TableColumn<>("Name");
    nameCol.setMinWidth(150);
    nameCol.setCellValueFactory(cellData -> cellData.getValue().nameProperty());
    nameCol.setCellFactory(cellFactory);
    nameCol.setOnEditCommit(
        (TableColumn.CellEditEvent<ObservableAssignment, String> t) -> {
          ObservableAssignment editAssignment = t.getTableView().getItems().get(t.getTablePosition().getRow());
          String oldValue = editAssignment.getName();
          editAssignment.setName(t.getNewValue());
          // Since the name is the primary key, rename assignment needs to remove old assignments first
          database.remove(oldValue);
          database.put(editAssignment.getName(), editAssignment);
          save.setDisable(false);
        });

    TableColumn<ObservableAssignment, String> detailsCol = new TableColumn<>("Assignment Details");
    detailsCol.setMinWidth(250);
    detailsCol.setCellValueFactory(cellData -> cellData.getValue().detailsProperty());
    detailsCol.setCellFactory(cellFactory);
    detailsCol.setOnEditCommit(
        (TableColumn.CellEditEvent<ObservableAssignment, String> t) -> {
          ObservableAssignment editAssignment = t.getTableView().getItems().get(t.getTablePosition().getRow());
          editAssignment.setDetails(t.getNewValue());
          database.put(editAssignment.getName(), editAssignment);
          save.setDisable(false);
        });

    TableColumn<ObservableAssignment, Date> startCol = new TableColumn<>("Start Date");
    startCol.setMinWidth(110);
    startCol.setCellValueFactory(cellData -> cellData.getValue().startProperty());
    startCol.setCellFactory(dateCellFactory);
    startCol.setOnEditCommit(
        (TableColumn.CellEditEvent<ObservableAssignment, Date> t) -> {
          ObservableAssignment editAssignment = t.getTableView().getItems().get(t.getTablePosition().getRow());
          if (t.getNewValue().compareTo(editAssignment.getDue()) > 0) {
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Edit");
            alert.setHeaderText("Your start date is after than you due date.");
            alert.showAndWait();
            return;
          }

          editAssignment.setStart(t.getNewValue());
          database.put(editAssignment.getName(), editAssignment);
          save.setDisable(false);
        });

    TableColumn<ObservableAssignment, Date> dueCol = new TableColumn<>("Due Date");
    dueCol.setMinWidth(110);
    dueCol.setCellValueFactory(cellData -> cellData.getValue().dueProperty());
    dueCol.setCellFactory(dateCellFactory);
    dueCol.setOnEditCommit(
        (TableColumn.CellEditEvent<ObservableAssignment, Date> t) -> {
          ObservableAssignment editAssignment = t.getTableView().getItems().get(t.getTablePosition().getRow());
          if (editAssignment.getStart().compareTo(t.getNewValue()) > 0) {
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Edit");
            alert.setHeaderText("Your due date is before than you start date.");
            alert.showAndWait();
            return;
          }
          editAssignment.setDue(t.getNewValue());
          database.put(editAssignment.getName(), editAssignment);
          // After due date is changes, we need to remove old timer and create a new one
          studentReminder.cancelTimer(editAssignment.getName());
          studentReminder.scheduleNotification(editAssignment);
          save.setDisable(false);
        });

    // Keep track of the selected row
    table.getSelectionModel().selectedItemProperty()
        .addListener((obs, oldSelection, newSelection) -> {
          if (newSelection != null) {
            selectedAssignment = newSelection;
          }
        });

    table.setEditable(true);
    table.setItems(data);
    table.getColumns().addAll(nameCol, detailsCol, startCol, dueCol);

    // Add new assignment from the bottom of the table
    final TextField addName = new TextField();
    addName.setPromptText("Name");
    addName.setMaxWidth(nameCol.getPrefWidth());

    final TextField addDetails = new TextField();
    addDetails.setPromptText("Details");
    addDetails.setMaxWidth(addDetails.getPrefWidth());

    final DatePicker addStart = new DatePicker();
    addStart.setPromptText("Start Date");
    addStart.setMaxWidth(addStart.getPrefWidth());

    final DatePicker addDue = new DatePicker();
    addDue.setPromptText("Due Date");
    addDue.setMaxWidth(addDue.getPrefWidth());

    final Button addButton = new Button("Quick Add");
    addButton.setOnAction((ActionEvent e) -> add(addName, addDetails, addStart, addDue));

    hb.getChildren().addAll(addName, addDetails, addStart, addDue, addButton);
    hb.setSpacing(3);

    // Save button to commit edits to database
    save.setDisable(true);
    save.setOnAction(e -> saveToDatabase());

    // For deleting assignment, we want to ask for confirmation
    Button delete = new Button("Delete");
    delete.setOnAction(e -> {
      if (selectedAssignment != null) {
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Delete Assignment");
        alert.setHeaderText("Deleting assignment \"" + selectedAssignment.getName() + "\"");
        alert.setContentText("Are you sure?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK) {
          data.remove(selectedAssignment);
          database.remove(selectedAssignment.getName());
          studentReminder.cancelTimer(selectedAssignment.getName());
          saveToDatabase();
        }
      }
    });

    // A Test button to simulate notification of the assignment
    Button test = new Button("Simulate Notification");
    test.setOnAction(e -> {
      if (selectedAssignment != null) {
        StudentReminder.notifyAssignment(selectedAssignment);
      }
    });

    // When logging out with unsaved edits, we want to ask for confirmation
    Button logout = new Button("Logout");
    logout.setOnAction(e -> {
      if (!save.isDisabled()) {
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Logout");
        alert.setHeaderText("You have unsaved assignments and you want to lose your changes");
        alert.setContentText("Are you sure?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK) {
          save.setDisable(true);
          studentReminder.cancelTimers();
          studentReminder.gotoSignIn(assignmentDB.getUsername(), "Successfully logout");
        }
      } else {
        studentReminder.cancelTimers();
        studentReminder.gotoSignIn(assignmentDB.getUsername(), "Successfully logout");
      }
    });

    final HBox mainHBox = new HBox();
    mainHBox.setSpacing(5);
    mainHBox.setAlignment(Pos.BASELINE_CENTER);
    mainHBox.getChildren().addAll(save, delete, logout);

    final HBox testHBox = new HBox();
    testHBox.setSpacing(5);
    testHBox.setAlignment(Pos.BASELINE_CENTER);
    testHBox.getChildren().addAll(test);

    final VBox vbox = new VBox();
    vbox.setSpacing(10);
    vbox.setPadding(new Insets(10, 0, 0, 10));
    vbox.getChildren().addAll(label, table, hb, mainHBox);

    //Setting the scene
    return new Scene(vbox, 700, 550);
  }

  /**
   * Add a new assignment and also save it to the database
   *
   * @param addName input control
   * @param addDetails input control
   * @param addStart input control
   * @param addDue input control
   */
  private void add(TextField addName, TextField addDetails, DatePicker addStart, DatePicker addDue) {
    if (!addName.getText().isEmpty() && !addName.getText().isEmpty()
        && addStart.getValue() != null && addDue.getValue() != null) {

      if (database.containsKey(addName.getText())) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle("Add");
        alert.setHeaderText("The assignment " + addName.getText() + " already exists.");
        alert.showAndWait();
        return;
      }
      if (addStart.getValue().compareTo(addDue.getValue()) > 0) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle("Add");
        alert.setHeaderText("Your due date is earlier than you start date.");
        alert.showAndWait();
        return;
      }

      ObservableAssignment newAssignment = new ObservableAssignment(
          addName.getText(),
          addDetails.getText(),
          Date.from(addStart.getValue().atStartOfDay(ZoneId.systemDefault()).toInstant()),
          Date.from(addDue.getValue().atStartOfDay(ZoneId.systemDefault()).toInstant()));
      data.add(newAssignment);
      database.put(newAssignment.getName(), newAssignment);
      save.setDisable(false);
      addName.clear();
      addDetails.clear();
      addStart.getEditor().clear();
      addDue.getEditor().clear();
      saveToDatabase();
      studentReminder.scheduleNotification(newAssignment);
    }
  }

  /**
   * Save all changes back to the database
   */
  private void saveToDatabase() {
    database.forEach((key, value) -> System.out.println(key + " " + value));
    save.setDisable(true);
    assignmentDB.saveDatabase();
  }
}