package application;

import java.util.Objects;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.image.Image;
import javafx.stage.Stage;

public class Main extends Application {

  @Override
  public void start(Stage primaryStage) {
    primaryStage.setTitle("Student Reminder");
    primaryStage.getIcons()
        .add(new Image(Objects.requireNonNull(getClass().getResourceAsStream("sr.png"))));
    StudentReminder studentReminder = new StudentReminder(primaryStage);
    primaryStage.setOnCloseRequest(t -> {
      // we want to cancel all timer before exit
      studentReminder.cancelTimers();
      Platform.exit();
      System.exit(0);
    });

    // Set the scene in primary stage
    studentReminder.gotoSignIn();
    primaryStage.show();
  }

  public static void main(String[] args) {
    launch(args);
  }
}
