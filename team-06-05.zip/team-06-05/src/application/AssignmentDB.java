package application;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.Map;

public class AssignmentDB {

  private final Map<String, ObservableAssignment> assignmentDatabase = new HashMap<>();

  private final String databaseFilename;
  private final String username;

  public Map<String, ObservableAssignment> getDatabase() {
    return assignmentDatabase;
  }

  public AssignmentDB(String username) {
    this.databaseFilename = "database/" + username;
    this.username = username;
    try (FileInputStream fis = new FileInputStream(databaseFilename);
        ObjectInputStream ois = new ObjectInputStream(fis)) {
      Map<String, Assignment> input = (Map<String, Assignment>) ois.readObject();
      input.forEach((s, a) -> assignmentDatabase.put(s,
          new ObservableAssignment(a.getName(), a.getDetails(), a.getStartDate(), a.getDueDate())));
      System.out.printf("Load DB (size=%s)%n", assignmentDatabase.size());
    } catch (FileNotFoundException fe) {
      System.out.println("no database file");
    } catch (Exception e) {
      System.out.println("Exception reading from database: " + e.getMessage());
    }
  }

  public String getUsername() {
    return username;
  }

  public void saveDatabase() {
    HashMap<String, Assignment> output = new HashMap<>();

    assignmentDatabase.forEach((s, a) -> output
        .put(s, new Assignment(a.getName(), a.getDetails(), a.getStart(), a.getDue())));

    System.out.printf("Saving to DB (size=%s)%n", output.size());
    try (FileOutputStream fos = new FileOutputStream(databaseFilename);
        ObjectOutputStream oos = new ObjectOutputStream(fos)) {
      oos.writeObject(output);
    } catch (IOException ioe) {
      System.out.println("Exception writing to database: " + ioe.getMessage());
    }
  }
}
