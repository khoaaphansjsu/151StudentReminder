package application;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.Map;

public class SRAccountDB {

  private Map<String, SRAccount> accountDatabase = new HashMap<>();
  private static final String ACCOUNT_DATABASE = "database/account.dat";

  public SRAccountDB() {
    loadAccountDatabase();
  }

  public void insertAccount(String username, String password) {
    accountDatabase.put(username, new SRAccount(username, password));

    // create database directory if not exists
    File database = new File(ACCOUNT_DATABASE);
    File parent = database.getParentFile();
    if (!parent.exists() && !parent.mkdirs()) {
      throw new IllegalStateException("Couldn't create dir: " + parent);
    }

    //create an output stream towards database file
    try (FileOutputStream fos = new FileOutputStream(ACCOUNT_DATABASE);
        ObjectOutputStream oos = new ObjectOutputStream(fos)) {
      oos.writeObject(accountDatabase);
      System.out.println("Successfully wrote to account.dat");
    } catch (IOException ioe) {
      System.out.println("An error occurred.");
      ioe.printStackTrace();
    }
  }

  public boolean validateLogin(String username, String password) {
    if (!accountDatabase.containsKey(username)) {
      return false;
    }
    return accountDatabase.get(username).validatePassword(password);
  }

  public boolean hasAccount(String user) {
    return accountDatabase.containsKey(user);
  }

  //read file
  private void loadAccountDatabase() {
    try (FileInputStream fis = new FileInputStream(ACCOUNT_DATABASE);
        ObjectInputStream ois = new ObjectInputStream(fis)) {
      accountDatabase = (Map<String, SRAccount>) ois.readObject();
    } catch (FileNotFoundException fe) {
      System.out.println("no account database file");
    } catch (IOException ioe) {
      if (ioe instanceof EOFException) {
        System.out.println("Account database empty");
      } else {
        ioe.printStackTrace();
      }
      return;
    } catch (ClassNotFoundException c) {
      System.out.println("Class not found");
      c.printStackTrace();
      return;
    }
  }
}
