package application;

import java.io.Serializable;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Arrays;

//Note: must deal with assignmentDB and Security

public class SRAccount implements Serializable {

  //Serialization for object stream
  private static final long serialVersionUID = 1L;


  private final String username;
  private final byte[] password;

  public SRAccount(String username, String password) {
    this.username = username;
    this.password = hashPassword(password);
  }

  public boolean validatePassword(String password) {
    return Arrays.equals(this.password, hashPassword(password));
  }

  private byte[] hashPassword(String password) {
    try {
      SecureRandom random = new SecureRandom();
      byte[] salt = new byte[16];
      random.nextBytes(salt);
      MessageDigest md = MessageDigest.getInstance("SHA-512");
      return md.digest(password.getBytes(StandardCharsets.UTF_8));

    } catch (NoSuchAlgorithmException e) {
      throw new IllegalArgumentException("unable to hash password", e);
    }
  }
}
