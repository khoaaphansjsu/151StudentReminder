package application;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.Window;

public class StudentReminder {

  public static final int SCENE_SIZE_Y = 500;
  public static final int SCENE_SIZE_X = 800;

  private final Stage stage;
  Scene signIn, signUp, homepage;

  private LogInSignUp login;

  public static final SRAccountDB accountDB = new SRAccountDB();
  AssignmentDB assignmentDB;
  private final Map<String, Timer> assignmentTimers = new HashMap<>();

  public StudentReminder(Stage primaryStage) {
    super();
    Locale.setDefault(Locale.US);
    this.stage = primaryStage;
    createLogin();
  }

  public void gotoSignIn(String username, String message) {
    login.setSignInUser(username, message);
    stage.setScene(signIn);
  }

  public void gotoSignIn() {
    stage.setScene(signIn);
  }

  public void gotoSignUp() {
    stage.setScene(signUp);
  }

  public void gotoHomepage() {
    stage.setScene(homepage);
  }

  public Stage getStage() {
    return stage;
  }

  public void createHomepage(String username) {
    assignmentDB = new AssignmentDB(username);
    AssignmentsController assignmentsController = new AssignmentsController(this, assignmentDB);
    homepage = assignmentsController.createScene();
  }

  public void createLogin() {
    login = new LogInSignUp(this);
    signIn = login.createSignIn();
    signUp = login.createSignUp();
  }

  public void scheduleNotifications() {
    for (Map.Entry<String, ObservableAssignment> entry : assignmentDB.getDatabase().entrySet()) {
      scheduleNotification(entry.getValue());
    }
  }

  public void scheduleNotification(ObservableAssignment assignment) {
    Calendar yesterday = Calendar.getInstance();
    yesterday.setTime(new Date());
    yesterday.add(Calendar.DATE, -1);

    if (yesterday.getTime().compareTo(assignment.getDue()) > 0) {
      System.out.printf("Event %s already expired on %s\n", assignment.getName(), assignment.getDue());
      return;
    }

    System.out.println("Schedule reminder for " + assignment.getName() + ":" + assignment);
    Timer timer = new Timer();
    timer.schedule(new TimerTask() {
      @Override
      public void run() {
        notifyAssignment(assignment);
      }
    }, assignment.getDue());
    assignmentTimers.put(assignment.getName(), timer);
  }

  public void cancelTimer(String name) {
    Timer timer = assignmentTimers.get(name);
    if (timer != null) {
      System.out.println("Cancelling timer: " + name);
      timer.cancel();
      assignmentTimers.remove(name);
    }
  }

  public void cancelTimers() {
    assignmentTimers.forEach((name, timer) -> {
      System.out.println("Cancelling timer: " + name);
      timer.cancel();
    });
    assignmentTimers.clear();
  }

  public static void notifyAssignment(ObservableAssignment assignment) {
    // I couldn't bring up the notification from Timer so runLater was a workaround I found online
    Platform.runLater(() -> {
      Alert alert = new Alert(AlertType.INFORMATION);
      alert.setTitle("Assignment due notification");
      alert.setHeaderText(String.format("Assignment \"%s\" is due on %s", assignment.getName(),
          assignment.getDue().toString()));
      alert.initModality(Modality.WINDOW_MODAL);
      alert.show();
    });
  }

  static void showAlert(Alert.AlertType alertType, Window window, String title, String message) {

    Alert alert = new Alert(alertType);
    alert.setTitle(title);
    alert.setHeaderText(null);
    alert.setContentText(message);
    alert.initOwner(window);
    alert.show();

  }
}
