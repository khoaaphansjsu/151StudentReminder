package application;

import java.util.Date;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class ObservableAssignment {
  private final SimpleStringProperty name;
  private final SimpleStringProperty details;
  private final SimpleObjectProperty<Date> start;
  private final SimpleObjectProperty<Date> due;

  public ObservableAssignment(String name, String details, Date start, Date due) {
    this.name = new SimpleStringProperty(name);
    this.details = new SimpleStringProperty(details);
    this.start = new SimpleObjectProperty(start);
    this.due = new SimpleObjectProperty(due);
  }

  public String getName() {
    return name.get();
  }

  public StringProperty nameProperty() {
    return this.name;
  }

  public void setName(String name) {
    this.name.set(name);
  }

  public String getDetails() {
    return details.get();
  }

  public StringProperty detailsProperty() {
    return this.details;
  }

  public void setDetails(String details) {
    this.details.set(details);
  }

  public Date getStart() {
    return start.get();
  }

  public ObjectProperty<Date> startProperty() {
    return this.start;
  }

  public void setStart(Date due) {
    this.due.set(due);
  }

  public Date getDue() {
    return due.get();
  }

  public ObjectProperty<Date> dueProperty() {
    return this.due;
  }

  public void setDue(Date due) {
    this.due.set(due);
  }

  @Override
  public String toString() {
    return "Assignment{" +
        "name=" + name.get() +
        ", details=" + details.get() +
        ", start=" + start.get() +
        ", due=" + due.get() +
        '}';
  }
}