package application;

import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

public class LogInSignUp {

  private final StudentReminder studentReminder;

  public LogInSignUp(StudentReminder studentReminder) {
    this.studentReminder = studentReminder;
  }

  final Label lblMessage = new Label();
  final TextField textUserName = new TextField();

  public void setSignInUser(String username, String message) {
    textUserName.setText(username);
    lblMessage.setText(message);
    lblMessage.setTextFill(Color.GREEN);
  }

  public Scene createSignIn() {

    // Scene: The Sign In Page
    GridPane gridPane = new GridPane();
    gridPane.setPadding(new Insets(20, 20, 30, 30));
    gridPane.setHgap(8);
    gridPane.setVgap(8);
    gridPane.setAlignment(Pos.CENTER);

    Text title = new Text("Sign In");
    title.setFont(Font.font("Arial", FontWeight.BOLD, 20));
    Label lblUserName = new Label("Username");
    Label lblPassword = new Label("Password");
    final PasswordField password = new PasswordField();
    Button btnLogin = new Button("Login");
    Label signupPromote = new Label("Don't have an account?");
    Hyperlink signUpLink = new Hyperlink("Sign Up");
    Button clearButton = new Button("Clear");
    Button cancelButton = new Button("Cancel");

    // Add action on the sign up link
    signUpLink.setOnAction(event -> studentReminder.gotoSignUp());

    // Add action on the log in button
    btnLogin.setOnAction(event -> {
      boolean validated = StudentReminder.accountDB
          .validateLogin(textUserName.getText(), password.getText());

      if (validated) {
        // go to the homepage
        studentReminder.createHomepage(textUserName.getText());
        studentReminder.scheduleNotifications();
        studentReminder.gotoHomepage();
      } else {
        lblMessage.setText("Wrong username/password!");
        lblMessage.setTextFill(Color.RED);
      }
      textUserName.setText("");
      password.setText("");
    });

    // Add action to the Clear button
    clearButton.setOnAction(event -> {
      textUserName.clear();
      password.clear();
      lblMessage.setText(null);
    });

    // Add action to the Cancel button
    cancelButton.setOnAction(event -> {
      Platform.exit();
      System.exit(0);
    });

    gridPane.add(title, 1, 0);
    gridPane.add(lblUserName, 0, 1);
    gridPane.add(textUserName, 1, 1);
    gridPane.add(lblPassword, 0, 2);
    gridPane.add(password, 1, 2);

    final HBox buttonHBox = new HBox();
    buttonHBox.setSpacing(10);
    buttonHBox.setAlignment(Pos.BASELINE_RIGHT);
    buttonHBox.getChildren().addAll(btnLogin, clearButton, cancelButton);

    gridPane.add(buttonHBox, 1, 3);
    gridPane.add(lblMessage, 1, 4);
    gridPane.add(signupPromote, 1, 5);
    gridPane.add(signUpLink, 2, 5);

    return new Scene(gridPane, StudentReminder.SCENE_SIZE_X, StudentReminder.SCENE_SIZE_Y);
  }

  Scene createSignUp() {

    // Scene 2: The sign Up Page
    Text signUpTitle = new Text("Sign Up");
    signUpTitle.setFont(Font.font("Arial", FontWeight.BOLD, 20));
    Label username = new Label("Username:");
    final TextField usernameField = new TextField();
    Label signUpPassword = new Label("New Password:");
    final PasswordField passwordField = new PasswordField();
    Label passwordConfirm = new Label("Confirm Password:");
    final PasswordField passwordConfirmField = new PasswordField();
    Button cancel = new Button("Cancel");
    cancel.setOnAction(e -> studentReminder.gotoSignIn());
    Button ok = new Button("OK");
    Button clear = new Button("Clear");
    ok.setDefaultButton(true);

    GridPane gridPane = new GridPane();
    gridPane.setPadding(new Insets(20, 20, 30, 30));
    gridPane.setHgap(8);
    gridPane.setVgap(8);
    gridPane.setAlignment(Pos.CENTER);
    gridPane.add(username, 0, 0);
    gridPane.add(usernameField, 1, 0);
    gridPane.add(signUpPassword, 0, 1);
    gridPane.add(passwordField, 1, 1);
    gridPane.add(passwordConfirm, 0, 2);
    gridPane.add(passwordConfirmField, 1, 2);

    HBox buttonHbox = new HBox(10);
    buttonHbox.setAlignment(Pos.BASELINE_CENTER);
    buttonHbox.getChildren().addAll(ok, clear, cancel);

    VBox mainVbox = new VBox(10);
    mainVbox.setAlignment(Pos.CENTER);
    mainVbox.setPadding(new Insets(10, 0, 0, 10));
    mainVbox.getChildren().addAll(signUpTitle, gridPane, buttonHbox);

    //Add action to the clearButton2
    clear.setOnAction(event -> {
      usernameField.clear();
      passwordField.clear();
      passwordConfirmField.clear();
    });

    // Add action on the submit button
    ok.setOnAction(event -> {

      if (usernameField.getText().isEmpty()) {
        StudentReminder.showAlert(Alert.AlertType.ERROR, studentReminder.signIn.getWindow(),
            "Error!", "Please Enter Your Name");
        return;
      }

      if (passwordField.getText().isEmpty()) {
        StudentReminder.showAlert(Alert.AlertType.ERROR, studentReminder.signUp.getWindow(),
            "Error!", "Password can't be blank");
        return;
      }

      // Check if the account or password is already used
      if (StudentReminder.accountDB.hasAccount(usernameField.getText())) {
        StudentReminder.showAlert(Alert.AlertType.ERROR, studentReminder.signUp.getWindow(),
            "Error!", "Username \"" + usernameField.getText() + "\" already exists");
        return;
      }

      if (!passwordField.getText().equals(passwordConfirmField.getText())) {
        StudentReminder.showAlert(Alert.AlertType.ERROR, studentReminder.signUp.getWindow(),
            "Error!", "Password confirmation doesn't match.");
        return;
      }

      StudentReminder.accountDB.insertAccount(usernameField.getText(), passwordField.getText());
      StudentReminder.showAlert(AlertType.INFORMATION, studentReminder.signUp.getWindow(),
          "Welcome " + usernameField.getText() + "!", "Account Successfully Created");
      setSignInUser(usernameField.getText(), "New user created");
      usernameField.clear();
      passwordField.clear();
      studentReminder.gotoSignIn();
    });

    return new Scene(mainVbox, StudentReminder.SCENE_SIZE_X, StudentReminder.SCENE_SIZE_Y);
  }
}
