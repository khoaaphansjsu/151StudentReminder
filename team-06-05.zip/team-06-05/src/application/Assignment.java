package application;

import java.io.Serializable;
import java.util.Date;

//must add notification
public class Assignment implements Serializable {

	private static final long serialVersionUID = 1L;

	private String name;
	private String details;
	private Date startDate;
	private Date dueDate;

	public Assignment(String name, String details, Date startDate, Date dueDate) {
		this.name = name;
		this.details = details;
		this.startDate = startDate;
		this.dueDate = dueDate;
	}

	@Override
	public String toString() {
		return "Assignment [name=" + name + ", details=" + details + ", startDate=" + startDate
				+ ", dueDate=" + dueDate + "]";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public Date getStartDate() {
		return this.startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getDueDate() {
		return this.dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}
}
